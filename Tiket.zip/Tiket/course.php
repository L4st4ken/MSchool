<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <title>Document</title>
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.js"></script>
    <style type="text/css">
        *{
            margin:  0;
            padding: 0;
            box-sizing: border-box;
            z-index: 2;
        }
        body{
            background: #e2e9f7;
            user-select: none;
            display: flex;
            overflow: hidden;   
        }
        #nav{
            display:flex;
            flex-direction: column;
            height: 100vh;
            width: 48px;
            display: block;
            background: #151525;
            overflow: hidden;
            transition-duration: .2s;
        }
        #nav a{
            text-decoration: none;
            width: 188px;
            color: #eee;
            height: 40px;
            display: inline-block;
            font-family: sans-serif;
            font-size: 20px;
            margin: 6px;
            transition-duration: .4s;
            border-radius: 16px;
        }
        #nav a:hover{
            background: #e2e9f7;
            color: #151525;
        }
        #nav a:active{
            transform: scale(0.5);
        }
         i{
            width: 48px;
            margin-right: 10px;
            padding: 6px;
        }
        #head{
            height: 48px;
            width: 200px;
            display: flex;
            align-items: center;
            font-size: 20px;
            color: #eee;
            background: #04040f;
        }
        #bars{
            display: inline-block;
            margin:0;
            font-size: 22px;
            padding: 14px;
            width: 48px;
            height: 48px;
            cursor: pointer;
            
        }
        #times{
            position:relative;
            left:20px;
            height:36px;
            cursor: pointer;

        }
        #va{
            font-size: 22px;
            font-family: sans-serif;
        }
        #sign{
            position: relative;
            top: 450px;
            background: #353545;
        }
        #sign:hover{
            color: #cf060e;
        }
        #info{
            margin-left: 6px;
        }
        #stud{
            position: relative;
            display: flex;
            justify-content: center;
            top: 80px;
        }
        #stud .edit{
            width: 100px;
            height: 40px;
            border: none;
            background: #eee;
            color: #151525;
            font-weight: 700;
        }
        #stud .edit:hover{
            transform:scale(0.9);
        }
        #stud .table-hover{
            background: #151525;
            color: white;
            border-radius: 12px;
        }
        #stud .page-link{
            background: #151525;
            color: white;
        }
        #stud .tambah{
            width: 100px;
            height: 40px;
            background: #151525;
            color: white;
            font-weight: 600;
            position: relative;
            bottom: 55px;
            left: 63vh;
        }
        #stud .tambah:hover{
            transform:scale(0.9);
        }
    </style>
    <script>
        $(document).ready( function () {
            $('#myTable').DataTable();
        } );
</script>
</head>
<body>
    <?php
    // Call file connect.php
    include_once("connection.php");
    // Retrieve all data from "books"
    $result = mysqli_query($mysqli, "SELECT * FROM matkul ORDER BY kode_mk ASC");
    $total_records = mysqli_num_rows($result);
    $per_page = 5; // Set the number of records per page
    $total_pages = ceil($total_records / $per_page);
    ?>
    <nav id="nav">
        <div id ="head">
            <div id="logo"></div>
            <i onclick="Open()" class="fa fa-bars" id="bars"></i>
            <div id="va"> MSchool </div>
            <i onclick="Close()" class = "fa fa-times" id="times"></i>
        </div>
        <a href="admin.php?username=<?php echo $_GET['username'];?>" id="nav1"><i class="fa fa-table"></i>Students</a>
        <a href="lecture.php?username=<?php echo $_GET['username'];?>" id="nav1"><i class="fa fa-table"></i>Lectures</a>
        <a href="course.php?username=<?php echo $_GET['username'];?>" id="nav1"><i class="fa fa-table"></i>Course</a>
        <a href="finance.php?username=<?php echo $_GET['username'];?>" id="nav1"><i class="fa fa-table"></i>Financial</a>
        <a href="logout.php" id="sign"><i class="fa fa-sign-out-alt"></i>Sign Out</a>
    </nav>
    <div class="container" id="stud">
        <div class="row">
            <div class="col-md-12 col-md-offset-3">
            <table id= "myTable"class="table table-bordered table-hover">
                <thead class="thead-light">
                    <tr>
                        <th>Course Code</th>
                        <th>Course Name</th>
                        <th>SKS</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $current_page = isset($_GET['page']) ? $_GET['page'] : 1;
                        $start = ($current_page - 1) * $per_page;
                        $result = mysqli_query($mysqli, "SELECT * FROM matkul ORDER BY kode_mk ASC LIMIT $start, $per_page");  
                        while($data = mysqli_fetch_array($result)) {         
                            echo "<tr>";
                            echo "<td>".$data['kode_mk']."</td>";
                            echo "<td>".$data['nama_mk']."</td>";
                            echo "<td>".$data['sks']."</td>";
                            echo"<td><a class='btn btn-primary btn-xs edit' href='./course/editc.php?username=$_GET[username]&CourseID=$data[kode_mk]'>Edit</a></td>";
                            echo"<td><a class='btn btn-primary btn-xs edit' href='./course/deletec.php?username=$_GET[username]&CourseID=$data[kode_mk]'>Delete</a></td>";        
                            echo "</tr>";
                        }
                    ?>
                </tbody>
                </table>
                <nav>
                    <ul class="pagination">
                        <?php for ($i = 1; $i <= $total_pages; $i++) { ?>
                            <li class="page-item <?php if ($i == $current_page) { echo "active"; } ?>"><a class="page-link" href="course.php?page=<?php echo $i; ?>&username=<?php echo $_GET['username'];?>"><?php echo $i; ?></a></li>
                        <?php } ?>
                    </ul>
                </nav>
                <a class="btn btn-primary tambah" href="./course/insertc.php?username=<?php echo $_GET['username']?>">Tambah</a>
            </div>
        </div>
    </div>

</body>

<script type="text/javascript">
    var nav = document.getElementById('nav');
    var bars = document.getElementById('bars');
    var va = document.getElementById('va');
    var btn = document.getElementById('button');

    function Open(){
        nav.style.width="200px";
        bars.style.display="none";
        va.style.marginLeft="50px";
    }
    function Close(){
        nav.style.width="48px";
        bars.style.display="inline-block";
    }
</script>
</html>