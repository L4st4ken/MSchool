<?php
$username1 = "root";
$password1 = "";
$database = "localhost";
$mysqli = mysqli_connect($database, $username1, $password1, "fproject_2"); 

// check connection
if (!$mysqli) {
    die("Connection Fail: " . mysqli_connect_error());
}

?>