<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r121/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vanta@latest/dist/vanta.net.min.js"></script>
    <style type="text/css">
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body{
            display: flex;
            justify-content: center;
            align-items:  center;
            min-height:  100vh;
            background: #e2e9f7;
        }

        .wrapper{
            border: 2px solid rgba(255, 255, 255, 2);
            width: 420px;
            background-color: #151525;
            color: #fff;
            border-radius: 10px;
            padding: 30px 40px;
        }

        .wrapper h1 {
            text-align: center;
            font-size: 36px;

        }

        .wrapper .input-box{
            position: relative;
            width: 100%;
            height: 50px;
            margin: 30px 0;
        }

        .input-box input{
            width: 100%;
            height: 100%;
            background: transparent;
            border: none;
            outline: none;
            border: 2px solid #fff;
            color: #fff;
            font-size: 16px;
            border-radius: 40px;
            padding: 20px 45px 20px 20px; 
        }

        .input-box input::placeholder{
            color: #fff;
        }

        .input-box i{
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
        }
        .input-box select{
            width: 100%;
            height: 100%;
            background: transparent;
            border: 2px solid #eee;
            font-size: 16px; 
            color: #eee;
            text-align: center;
            border-radius: 40px;
        }
        .input-box select option{
            color: #000;
        }
        .wrapper .btn{
            width: 100%;
            height: 50px;
            font-size: 16px;
            font-weight: 600;
            border-radius: 20px;
            border: none;
            box-shadow: 0 0 10px rgba(0,0,0, .5);
            cursor: pointer;
        }
    
        #net{
            width: 100%;
            height: 100%;
            position: absolute;
            display: flex;
            justify-content: center;
            align-items: center;

        }
    </style>
</head>
<body>
    <div id="net">    
        <div class="wrapper">
                <form action="signup.php" method="post">
                    <h1>Register</h1>
                    <div class="input-box">
                        <input type="text" placeholder="Username" name="username" required>
                        <i class='bx bxs-user'></i>
                    </div>
                    <div class="input-box">
                        <input type="password" placeholder="Password" name="password" required>
                        <i class='bx bxs-lock' ></i>
                    </div>
                    <div class="input-box">
                        <select name="level" id="level" onclick="openDrop()">
                            <option value="" id="role">Select Your Role</option>
                            <option value="mhs" disabled>Mahasiswa</option>
                            <option value="dos" disabled>Dosen</option>
                        </select>
                    </div>
                    <button type="submit" name="kumpul" class="btn">Register</button>
                </form>
        </div>
    </div>
</body>
<?php
if(isset($_POST['kumpul'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];
    $level    = $_POST['level'];

    // Make hash from password using PASSWORD_BCRYPT algoritm
    $hash = password_hash($password, PASSWORD_BCRYPT);

    // include file connect.php
    include_once("connection.php");

    // Check if the username already exists in the database
    $result = mysqli_query($mysqli, "SELECT * FROM users WHERE username='$username'");
    $count = mysqli_num_rows($result);

    if($count == 0) {
        // username doesn't exist, proceed with insertion
        mysqli_query($mysqli, "INSERT INTO users(username,password, level) VALUES('$username','$hash', '$level')"); 
header("Location: login.php");
        // Redirect page to datatable.php
        
    } else {
        // username already exists, handle accordingly (e.g., show an error message)
        echo "<script>
            alert('Username already registered.');
            window.location.href = 'signup.php';
        </script>";;
    }
}
?>
<script type="text/javascript">
    var selectLevel = document.getElementById('level');
    var role = document.getElementById('role');
    
    function openDrop(){
        role.disabled = true;
        for(var i = 1; i<selectLevel.options.length; i++){
            selectLevel.options[i].disabled = false;
        }
    }
</script>

<script>
        VANTA.NET({
        el: "#net",
        mouseControls: true,
        touchControls: true,
        gyroControls: false,
        minHeight: 200.00,
        minWidth: 200.00,
        scale: 1.00,
        scaleMobile: 1.00
        })
    </script>
</html>