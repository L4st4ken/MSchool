<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r121/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vanta@latest/dist/vanta.net.min.js"></script>
    <style type="text/css">
        *{
            margin:  0;
            padding: 0;
            box-sizing: border-box;
            z-index: 2;
        }
        body{
            background: #e2e9f7;
            user-select: none;
            display: flex;
        }
        h1 {
            font-family: sans-serif;
            position: fixed;
            top: 50px;
            left: 350px;
            font-size: 40px;
            color: #eee;
        }
        .h1v2{
            font-family: sans-serif;
            position: fixed;
            top: 150px;
            left: 350px;
            font-size: 40px;
        }
        img{
            position: relative ;
            top: 250px;
            left: 75vh;
            border-radius: 20px;
        }
        .button{
            background: #151525;
            color: #eee;
            width: 300px;
            height: 55px;
            min-width: 120px;
            font-family: sans-serif;
            font-weight: 700;
            font-size: 15px;
            padding: 10px;
            cursor:pointer;
            border-radius: 20px;
            border: none;

        }
        .signup{
            position: fixed;
            top: 670px;
            left: 950px;
        }
        .login{
            position: fixed;
            left: 400px;
            top: 670px;
        }
        .login:hover{
            background: #eee;
            color: #151525;
            transform: scale(0.9);
            transition-duration: .2s;
            
        }
        #abtn{
            text-decoration: none;
            width: 188px;
            color: #eee;
            height: 40px;
            display: inline;
            font-family: sans-serif;
            font-size: 20px;
            margin: 6px;
            transition-duration: .4s;
            border-radius: 16px;
        }
        #net{
            width: 100%;
            height: 100%;
            position: absolute;
        }
        #button:hover{
            background: #eee;
            color: #151525;
            transform: scale(0.9);
            transition-duration: .2s;
        }
    </style>
</head>
<body>
    
    <div id="bd1">
        <div id="net">
            <h1>How Are You Today? Get Tired With Homework?</h1>
            <h1 class="h1v2">Nice Try Bang . . . .</h1>
            <img src="hw1.jpeg" alt="homework.gif" width="500" height="390">
            <a href="signup.php" id="abtn"><button type="button" id="button" class = "button signup"hover="hover()">Daftar Disini Yukk!!</button></a>
            <a href="login.php" id="abtn"><button type="button" class="button login" hover="hover()">Sudah Punya Akun</button></a>
        </div>
    </div>
</body>
<script>
        VANTA.NET({
        el: "#net",
        mouseControls: true,
        touchControls: true,
        gyroControls: false,
        minHeight: 200.00,
        minWidth: 200.00,
        scale: 1.00,
        scaleMobile: 1.00
        })
    </script>
</html>