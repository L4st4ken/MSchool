<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r121/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vanta@latest/dist/vanta.net.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <style type="text/css">
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: "Poppins", sans-serif;
        }

        body{
            display: flex;
            justify-content: center;
            align-items:  center;
            min-height:  100vh;
            background: #e2e9f7;
        }

        .wrapper{
            border: 2px solid rgba(255, 255, 255, 2);
            width: 420px;
            background-color: #151525;
            color: #fff;
            border-radius: 10px;
            padding: 30px 40px;
        }

        .wrapper h1 {
            text-align: center;
            font-size: 36px;

        }

        .wrapper .input-box{
            position: relative;
            width: 100%;
            height: 50px;
            margin: 30px 0;
        }

        .input-box input{
            width: 100%;
            height: 100%;
            background: transparent;
            border: none;
            outline: none;
            border: 2px solid #fff;
            color: #fff;
            font-size: 16px;
            border-radius: 40px;
            padding: 20px 45px 20px 20px; 
        }

        .input-box input::placeholder{
            color: #fff;
        }

        .input-box i{
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
        }
        .input-box select{
            width: 100%;
            height: 100%;
            background: transparent;
            border: 2px solid #eee;
            font-size: 16px; 
            color: #eee;
            text-align: center;
            border-radius: 40px;
        }
        .input-box select option{
            color: #000;
        }
        .wrapper .btn{
            width: 100%;
            height: 50px;
            font-size: 16px;
            font-weight: 600;
            border-radius: 20px;
            border: none;
            box-shadow: 0 0 10px rgba(0,0,0, .5);
            cursor: pointer;
        }
    
        #net{
            width: 100%;
            height: 100%;
            position: absolute;
            display: flex;
            justify-content: center;
            align-items: center;

        }
    </style>
</head>
<body>
<?php
    include_once("../connection.php");
    $isbn = $_GET['username'];
    $nim = $_GET['LectureID'];
    $result = mysqli_query($mysqli, "SELECT * FROM Lecture WHERE Lecture_ID = '$nim'");
    while($data = mysqli_fetch_array($result)) {
        $user = $data['Username'];
        $author = $data['Name'];
        $price = $data['Email'];
     }
?>
<?php
        if(isset($_POST['hey'])){
            echo "<div>sccesss</div>";
            $nim = $_POST['NIM'];
            $name = $_POST['Name'];
            $email = $_POST['Email'];

            include_once("../connection.php");

            mysqli_query($mysqli, "UPDATE lecture SET Name = '$name', Email='$email' WHERE Lecture_ID='$nim'");
            header("Location: ../Lecture.php?username=".$_GET['username']);
        }else{
            echo "<div>Noooosss</div>";
        }   
    ?>

    <div id="net">    
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                    <form action="" method="post">
                                    <div class="mb-3">
                                        <label class="form-label">Username</label>
                                        <input type="text" name="Username1" class="form-control" placeholder="Username" value="<?php echo $user;?>" disabled>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">NIM</label>
                                        <input type="text" name="NIM" class="form-control" placeholder="NIM" value="<?php echo $nim;?>" >
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Name</label>
                                        <input type="text" name="Name" class="form-control" placeholder="Name" value="<?php echo $author;?>">
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label">Email</label>
                                        <input type="text" name="Email" class="form-control" placeholder="Email" value="<?php echo $price;?>">
                                    </div>
                                    <br>
                                    <button type="submit" name="hey" class="btn btn-primary">Update</button>
                                    
                        </form>           
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</body>

<script>
        VANTA.NET({
        el: "#net",
        mouseControls: true,
        touchControls: true,
        gyroControls: false,
        minHeight: 200.00,
        minWidth: 200.00,
        scale: 1.00,
        scaleMobile: 1.00
        })
    </script>
</html>