<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r121/three.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/vanta@latest/dist/vanta.net.min.js"></script>
    <title>Document</title>
    <style type="text/css">
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: sans-serif;
            z-index: 2;
        }

        body{
            display: flex;
            justify-content: center;
            align-items:  center;
            min-height: 100vh;
            background: #e2e9f7;
        }

        .wrapper{
            border: 2px solid rgba(255, 255, 255, 2);
            width: 420px;
            background-color: #151525;
            color: #fff;
            border-radius: 10px;
            padding: 30px 40px;
        }

        .wrapper h1 {
            text-align: center;
            font-size: 36px;

        }

        .wrapper .input-box{
            position: relative;
            width: 100%;
            height: 50px;
            margin: 30px 0;
        }

        .input-box input{
            width: 100%;
            height: 100%;
            background: transparent;
            border: none;
            outline: none;
            border: 2px solid #fff;
            color: #fff;
            font-size: 16px;
            border-radius: 40px;
            padding: 20px 45px 20px 20px; 
        }

        .input-box input::placeholder{
            color: #fff;
        }

        .input-box i{
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 20px;
        }

        .wrapper .remember-forgot{
            display: flex;
            justify-content: space-between;
            font-size:  14px;
            margin: -15px 0 15px;
        }

        .remember-forgot a{
            color: white;
            text-decoration: none;
        }

        .remember-forgot a:hover{
            text-decoration: underline;
        }

        .wrapper .btn{
            width: 100%;
            height: 50px;
            font-size: 16px;
            font-weight: 600;
            border-radius: 20px;
            border: none;
            box-shadow: 0 0 10px rgba(0,0,0, .5);
            cursor: pointer;
        }

        .wrapper .register-link{
            margin: 20px 0 15px;
            font-size: 14px;
        }
        .register-link a{
            color: #fff;
            text-decoration: none;
            font-weight: 700;
        }
        .register-link a:hover{
            text-decoration: underline;
        }
        #net{
            width: 100%;
            height: 100%;
            position: absolute;
            display: flex;
            justify-content: center;
            align-items: center;
            
        }
    </style>
</head>
<body>
<?php
if(isset($_POST['submit'])) {

    $username = $_POST['username'];
    $password = $_POST['pasword'];


    // include file connect.php
    include_once("connection.php");

    // Check if the username exists in the database
    $result = mysqli_query($mysqli, "SELECT * FROM users WHERE username='$username'");
    $count = mysqli_num_rows($result);

    if($count == 1) {
        // username exists, verify the password
        $row = mysqli_fetch_assoc($result);
        $hash = $row['Password'];
        $lvl = $row['Level'];

        if(password_verify($password, $hash)) {
            // password is correct, start a session and redirect to index.php
            $_SESSION['username'] = $username;
            $_SESSION['Level'] = $lvl;
            
                if($lvl == 'mhs'){
                    $rsStudent = mysqli_query($mysqli, "SELECT * FROM student WHERE username = '$username'");
                    $countStudent = mysqli_num_rows($rsStudent);
                    if($countStudent == 0){
                        header('Location: form.php?username=' . $username . '&level=mhs');
                    }else {
                        session_start();
                        header('Location: /Tiket/mhs/MyResume/index.html?username='.$username);
                    }
                    

                }else if($lvl == 'dos'){
                    $rsLecture = mysqli_query($mysqli, "SELECT * FROM Lecture WHERE username = '$username'");
                    $countLecture = mysqli_num_rows($rsLecture);
                    if($countLecture == 0){
                        header('Location: form.php?username=' . $username . '&level=dos');
                    }else{
                        session_start();
                        header('Location: /Tiket/dos/MyResume/index.php?username='.$username);
                    }
                    
                }else if($lvl == 'adm'){
                    session_start();
                    header('Location: admin.php?username='.$username);
                }
            
                
        } else {
            // password is incorrect, show an error message
            echo "<script>
            alert('Username Or Password Is Wrong');
            window.location.href='login.php';
            </script>";
        }
    } else {
        // username doesn't exist, show an error message
        echo "<script>
            alert('Username Is Not Registered);
            window.location.href='login.php';
            </script>";
    }
}
?>
    <div id="net">
        <div class="wrapper">
            <form action="login.php" method="post">
                <h1>Login</h1>
                <div class="input-box">
                    <input type="text" placeholder="Username" name="username" required>
                    <i class='bx bxs-user'></i>
                </div>
                <div class="input-box">
                    <input type="password" placeholder="Password" name="pasword" required>
                    <i class='bx bxs-lock' ></i>
                </div>

                <div class="remember-forgot">
                    <label><input type="checkbox"> Remember me</label>
                    <a href="#">Forgot password?</a>
                </div>

                <button type="submit" name="submit" class="btn">Login</button>

                <div class="register-link">
                    <p>Dont have an account? <a href="signup.php">Register</a></p>
                </div>
            </form>
        </div>
    </div>
    
</body>

<script>
        VANTA.NET({
        el: "#net",
        mouseControls: true,
        touchControls: true,
        gyroControls: false,
        minHeight: 200.00,
        minWidth: 200.00,
        scale: 1.00,
        scaleMobile: 1.00
        })
    </script>
</html>